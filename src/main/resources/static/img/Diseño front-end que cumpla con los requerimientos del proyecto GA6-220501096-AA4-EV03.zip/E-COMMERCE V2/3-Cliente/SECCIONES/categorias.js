document.addEventListener('DOMContentLoaded', function() {
    // Funcionalidad del carrito
    const cartIcon = document.querySelector('.cart-icon');
    const cartContainer = document.querySelector('.cart-container');
    const closeCartButton = document.querySelector('.close-cart');

    // Mostrar/Ocultar carrito
    cartIcon.addEventListener('click', () => {
        cartContainer.classList.remove('hidden');
    });

    closeCartButton.addEventListener('click', () => {
        cartContainer.classList.add('hidden');
    });

    // Cerrar carrito al hacer clic fuera
    document.addEventListener('click', function(event) {
        if (!cartContainer.contains(event.target) && !cartIcon.contains(event.target)) {
            cartContainer.classList.add('hidden');
        }
    });

    // Actualizar visualización inicial del carrito
    CartManager.updateDisplay();
}); 