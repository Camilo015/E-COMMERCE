document.addEventListener('DOMContentLoaded', function() {
    // Funcionalidad del carrito
    const cartIcon = document.querySelector('.cart-icon');
    const cartContainer = document.querySelector('.cart-container');
    const closeCartButton = document.querySelector('.close-cart');
    const servicioButtons = document.querySelectorAll('.solicitar-servicio');

    // Mostrar/Ocultar carrito
    cartIcon.addEventListener('click', () => {
        cartContainer.classList.remove('hidden');
    });

    closeCartButton.addEventListener('click', () => {
        cartContainer.classList.add('hidden');
    });

    // Cerrar carrito al hacer clic fuera
    document.addEventListener('click', function(event) {
        if (!cartContainer.contains(event.target) && !cartIcon.contains(event.target)) {
            cartContainer.classList.add('hidden');
        }
    });

    // Actualizar visualización inicial del carrito
    CartManager.updateDisplay();

    // Agregar eventos a los botones de "Solicitar Servicio"
    servicioButtons.forEach(button => {
        button.addEventListener('click', () => {
            const servicioCard = button.closest('.servicio-card');
            const servicioNombre = servicioCard.querySelector('h3').textContent;
            showNotification(`Has solicitado el servicio: ${servicioNombre}`);
        });
    });

    // Función para mostrar notificaciones
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 2000);
        }, 100);
    }
}); 