import numpy as np
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Embedding, Flatten
from tensorflow.keras.utils import to_categorical

# Datos de ejemplo
nombres = np.array(['Juan', 'Ana', 'Pedro', 'Maria', 'Luis', 'Sofia'])
etiquetas = np.array([0, 1, 0, 1, 0, 1])  # 0 y 1 son etiquetas de ejemplo

# Codificar los nombres como enteros
encoder = LabelEncoder()
nombres_codificados = encoder.fit_transform(nombres)

# Convertir etiquetas a formato categórico
etiquetas_categoricas = to_categorical(etiquetas)

# Definir el modelo
def crear_modelo():
    model = Sequential()
    model.add(Embedding(input_dim=len(nombres), output_dim=8, input_length=1))
    model.add(Flatten())
    model.add(Dense(10, activation='relu'))
    model.add(Dense(2, activation='softmax'))
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# K-Fold Cross Validation
kfold = KFold(n_splits=3, shuffle=True, random_state=42)
resultados = []

for train, test in kfold.split(nombres_codificados):
    model = crear_modelo()
    model.fit(nombres_codificados[train], etiquetas_categoricas[train], epochs=10, verbose=0)
    scores = model.evaluate(nombres_codificados[test], etiquetas_categoricas[test], verbose=0)
    print(f"Accuracy: {scores[1] * 100}")
    resultados.append(scores[1] * 100)

print(f"Promedio de accuracy: {np.mean(resultados)}")
