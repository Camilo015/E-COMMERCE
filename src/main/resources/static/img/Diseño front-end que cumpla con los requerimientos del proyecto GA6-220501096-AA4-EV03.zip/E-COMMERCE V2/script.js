const wrapper = document.querySelector('.wrapper');
const LinkIngreso = document.querySelector('.Link-de-ingreso');
const LinkRegistro = document.querySelector('.Link-de-registro');

const btnPopup = document.querySelector('.btnLogin-popup');

const IconClose = document.querySelector('.icon-close');

LinkRegistro.addEventListener('click', ()=>{
    wrapper.classList.add('active');
});

LinkIngreso.addEventListener('click', ()=>{
    wrapper.classList.remove('active');
});

btnPopup.addEventListener('click', ()=>{
    wrapper.classList.add('active-popup');
});

IconClose.addEventListener('click', ()=>{
    wrapper.classList.remove('active-popup');
});